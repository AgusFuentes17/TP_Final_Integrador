package controlador;

public class Vender {
    
}
