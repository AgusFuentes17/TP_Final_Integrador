package controlador;

public class Total {
    
}
