package modelo;

//Esta clase representa un producto de la base de datos; Hecho por Candia
public class Producto {
    
    //Atributos
    private int idProd;
    private String nombre;
    Categoria categoria;
    private double precio;
    private int cantidad;

    //Constructor
    public Producto(String n, Categoria c, double p, int cant) {
        this.nombre = n;
        this.categoria = c;
        this.precio = p;
        this.cantidad = cant;
    }

    //Getters y Setters

    public void setIdProd(int id){
        this.idProd = id;
    }

    public int getIdProd(){
        return this.idProd;
    }

    public void setNombre(String n){
        this.nombre = n;
    }

    public String getNombre(){
        return this.nombre;
    }

    public void setCategoria(Categoria cat){
        this.categoria = cat;
    }

    public Categoria getCategoria(){
        return this.categoria;
    }

    public void setPrecio(double p){
        this.idCarrito = id;
    }

    public double getPrecio(){
        return this.precio;
    }

    public void setCantidad(int cant){
        this.cantidad = cant;
    }

    public int getCantidad(){
        return this.cantidad;
    }

    //Método toString
    @Override
    public String toString(){
        return ""+this.nombre + this.categoria + this.precio + this.cantidad;
    }
    
}
