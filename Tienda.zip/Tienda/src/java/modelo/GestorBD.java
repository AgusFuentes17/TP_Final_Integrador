package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

//Clase que realizará todas las relaciones con la base de datos; Hecho por Agustín Fuentes
public class GestorBD {

    //Atributos
    Connection conn = null;
    Statement stm = null;
    PreparedStatement pstm = null;
    ResultSet rs;
    Producto prod;
    Venta venta;
    Historial hist;
    
    //Método para agregar un producto a la base de datos
    public boolean agregarProducto(String n, Categoria c, Double p, int cant) throws SQLException{
        int resultado;
        try{ 
            conn = ConectarBD.abrir();

            //Se llama al Stored Procedure para agregar un registro de producto a la base de datos
            stm = conn.createStatement();
            String sql = "call agregar_producto_sp('"+n+"', '"+c+"' , "+p+", "+cant+");";
            resultado = stm.executeUpdate(sql);

            //Evalúa si la acción se realiza o no
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
        }catch (SQLException e){
                System.out.println("Error en la Base de Datos");
                return false;
        }
    }
    
    //Método para filtrar productos por categoria
    public ArrayList<Producto> buscarProducto(String cat){
        ArrayList<Producto> productos = new ArrayList<>();
        try{
            conn = ConectarBD.abrir();

            //Se llama al Stored Procedure para buscar los registro de producto, en la base de datos, que coincidan con la busqueda
            stm = conn.createStatement();
            String sql = "call buscar_producto_sp('"+cat+"');";
            rs = stm.executeQuery(sql);

            //Evalúa si hay registros o no
            if(!rs.next()){
                System.out.println("No se encontró el registro");
                ConectarBD.cerrar();
                return null;
            }else{ //Agrega al ArrayList productos los atributos hasta que no haya registros
                do{
                    String nombre = rs.getString("nombre");
                    Categoria categoria = Categoria.valueOf(rs.getString("categoria"));
                    double precio = rs.getDouble("precio");
                    int cant = rs.getInt("cantidad");
                    Producto p = new Producto(nombre, categoria, precio, cant);
                    productos.add(p);
                }while(rs.next());
                
                ConectarBD.cerrar();
                return productos;
            }
        }catch (SQLException e){
            System.out.println("Error en la base de datos");
            return null;
        }
    }
    
    //Método para eliminar un producto de la base de datos
    public boolean eliminarProducto(int id) throws SQLException{
        int resultado;
        try{ 
            conn = ConectarBD.abrir();

            //Se llama al Stored Procedure para eliminar el registro de producto con ese id de la base de datos 
            stm = conn.createStatement();
            String sql = "call eliminar_producto_sp("+id+");";
            resultado = stm.executeUpdate(sql);

            //Evalúa que se realizó correctamente esa acción
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
        }catch (SQLException e){
                System.out.println("Error en la Base de Datos");
                return false;
        }
    }
    
    //Método para actualizar el stock y precio de un producto
    public boolean actualizarProducto(int id, int cant, double precio) throws SQLException{
        int resultado;
        try{
            conn = ConectarBD.abrir();

            //Llama al Stored Procedure para actualizar el registro de la base de datos
            stm = conn.createStatement();
            String sql = "call actualizar_producto_sp("+id+","+cant+","+precio+");";
            resultado = stm.executeUpdate(sql);

            //Verifica si se realizó la acción correctamente
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
        }catch (SQLException e){
                System.out.println("Error en la Base de Datos");
                return false;
        }
    }

    //Método para ver el total vendido entre 2 fechas
    public double verTotalVentas(String fechaIn, String fechaFin) throws SQLException{
        try{
            conn = ConectarBD.abrir();
            LocalDate fechaI = LocalDate.parse(fechaIn);
            LocalDate fechaF = LocalDate.parse(fechaFin);

            //Selecciona a la función para ver el total
            String sql = "select verTotalVendido(?, ?) as total";
            pstm = conn.prepareStatement(sql);
            pstm.setDate(1, java.sql.Date.valueOf(fechaI));
            pstm.setDate(2, java.sql.Date.valueOf(fechaF));
            rs = pstm.executeQuery();
            double total = 0.0;

            //Verifica que hay registros, y asigna el total a la variable total
            if(rs.next()){
                total = rs.getDouble("total");
                ConectarBD.cerrar();
                return total;
            }else{
                ConectarBD.cerrar();
                return 0;
            }
        }catch (SQLException e){
                System.out.println("Error en la Base de Datos");
                return 0;
        }
    }

    //Método para ver el producto más vendido
    public String verProdMasVendido() throws SQLException{
        try{
            conn = ConectarBD.abrir();
            
            //Selecciona la función para ver el producto más vendido
            String sql = "select verMasVendido() as prod;";
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            String producto = "";

            //Verifica que hay registros, y asigna el producto más vendido a la variable producto
            if(rs.next()){
                producto = rs.getString("prod");
                ConectarBD.cerrar();
                return producto;
            }else{
                ConectarBD.cerrar();
                return null;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return null;
    }
    }
    
    //Método para agregar productos al carrito 
    public ItemCarrito agregarCarrito(int id, int cant) throws SQLException{
        try{
            conn = ConectarBD.abrir();
            
            //Selecciona las funciones para obtener el precio y el nombre del producto con el id
            String sql = "select obtenerPrecio("+id+") as pre;";
            rs = pstm.executeQuery(sql);
            double pre;
            
            String sql2 = "select obtenerNombre("+id+") as nom;";
            rs = pstm.executeQuery(sql2);
            String nom;
            
            //Verifica que hay registros, y asigna el precio y nombre a las variables pre y nom respectivamente
            if(rs.next()){
                pre = rs.getDouble("pre");
                nom = rs.getString("nom");
                ItemCarrito carrito = new ItemCarrito(id, cant, pre, nom);
                ConectarBD.cerrar();
                return carrito;
            }else{
                ConectarBD.cerrar();
                return null;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return null;
    }
    }

    //Método para agregar una venta a la base de datos
    public boolean crearVenta(List<ItemCarrito> carrito) throws SQLException{
        try{
            int[] resultado = new int[carrito.size()];
            int res;
            conn = ConectarBD.abrir();
            conn.setAutoCommit(false);

            LocalDate fecha = LocalDate.now();
            
            //Llama al Stored Procedure para agregar un registro de venta
            String idsql = "call realizar_venta_sp(fechaVenta) VALUES (?)";
            pstm = conn.prepareStatement(idsql, Statement.RETURN_GENERATED_KEYS);
            pstm.setDate(1, java.sql.Date.valueOf(fecha));
            
            //Obtiene la key generada con esa consulta
            int filas = pstm.executeUpdate();
                rs = pstm.getGeneratedKeys();

                //Verifica que la key se genere
                if (rs.next()){
                    int idVenta = rs.getInt(1);            

                    //Llama al Stored Procedure para realizar la descripción de la venta
                    String sql = "call realizar_descripcion_venta_sp(?, ?, ?, ?);";
                    pstm = conn.prepareStatement(sql);
                    
                    //Por cada item del carrito, agrega un registro de la descripción
                    for(ItemCarrito item : carrito){
                        pstm.setInt(1, idVenta);
                        pstm.setInt(2, item.getIdProd());
                        pstm.setInt(3, item.getCantidad());
                        pstm.setDouble(4, item.getPrecio() * item.getCantidad());
                        
                        pstm.addBatch();
                    }

                    resultado = pstm.executeBatch();
                    conn.commit();
                    conn.setAutoCommit(true);
                    res = 1;
                } else{
                    conn.rollback();
                    res = null;
                }

            //verifica que la acción se haya realizado correctamente, si no, hace un rollback
            if(res != null){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
    }
}
