package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GestorBD {
    Connection conn = null;
    Statement stm = null;
    ResultSet rs;
    Producto prod;
    Venta venta;
    Historial hist;
    
    public boolean agregarProducto(String n, Categoria c, double p, int cant) throws SQLException{
        int resultado;
        try{
            conn = ConectarBD.abrir();
            stm = conn.createStatement();
            String cat = c.toString();
            String sql = "insert into Producto (nombre, categoria, precio, cantidad) values("+n+", "+cat+", "+p+", "+cant+");";
            resultado = stm.executeUpdate(sql);
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
    }
}
