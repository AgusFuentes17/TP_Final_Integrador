package modelo;

public class GestorBD {
    
}
