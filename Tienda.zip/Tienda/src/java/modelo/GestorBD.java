package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

public class GestorBD {
    Connection conn = null;
    Statement stm = null;
    PreparedStatement pstm = null;
    ResultSet rs;
    Producto prod;
    Venta venta;
    Historial hist;
    
    public boolean agregarProducto(String n, Categoria c, Double p, int cant) throws SQLException{
        int resultado;
        try{
            conn = ConectarBD.abrir();
            stm = conn.createStatement();
            String sql = "call agregar_producto_sp('"+n+"', '"+c+"' , "+p+", "+cant+");";
            resultado = stm.executeUpdate(sql);
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
    }
    
    public ArrayList<Producto> buscarProducto(String cat){
        ArrayList<Producto> productos = new ArrayList<>();
        try{
            conn = ConectarBD.abrir();
            stm = conn.createStatement();
            String sql = "call buscar_producto_sp('"+cat+"');";
            rs = stm.executeQuery(sql);
            if(!rs.next()){
                System.out.println("No se encontró el registro");
                ConectarBD.cerrar();
                return null;
            }else{
                do{
                    String nombre = rs.getString("nombre");
                    Categoria categoria = Categoria.valueOf(rs.getString("categoria"));
                    double precio = rs.getDouble("precio");
                    int cant = rs.getInt("cantidad");
                    Producto p = new Producto(nombre, categoria, precio, cant);
                    productos.add(p);
                }while(rs.next());
                
                ConectarBD.cerrar();
                return productos;
            }
        }catch (SQLException e){
            System.out.println("Error en la base de datos");
            return null;
        }
    }
    
    public boolean eliminarProducto(int id) throws SQLException{
        int resultado;
        try{
            conn = ConectarBD.abrir();
            stm = conn.createStatement();
            String sql = "call eliminar_producto_sp("+id+");";
            resultado = stm.executeUpdate(sql);
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
        
        
    }
    
    public boolean actualizarProducto(int id, int cant, double precio) throws SQLException{
        int resultado;
        try{
            conn = ConectarBD.abrir();
            stm = conn.createStatement();
            String sql = "call actualizar_producto_sp("+id+","+cant+","+precio+");";
            resultado = stm.executeUpdate(sql);
            if(resultado != 0){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
    }

    public double verTotalVentas(String fechaIn, String fechaFin) throws SQLException{
        try{
            conn = ConectarBD.abrir();
            LocalDate fechaI = LocalDate.parse(fechaIn);
            LocalDate fechaF = LocalDate.parse(fechaFin);
            String sql = "select verTotalVendido(?, ?) as total";
            pstm = conn.prepareStatement(sql);
            pstm.setDate(1, java.sql.Date.valueOf(fechaI));
            pstm.setDate(2, java.sql.Date.valueOf(fechaF));
            rs = pstm.executeQuery();
            double total = 0.0;

            
            if(rs.next()){
                total = rs.getDouble("total");
                ConectarBD.cerrar();
                return total;
            }else{
                ConectarBD.cerrar();
                return 0;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return 0;
    }
    }

    public String verProdMasVendido() throws SQLException{
        try{
            conn = ConectarBD.abrir();
            
            String sql = "select verMasVendido() as prod;";
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            String producto = "";

            if(rs.next()){
                producto = rs.getString("prod");
                ConectarBD.cerrar();
                return "";
            }else{
                ConectarBD.cerrar();
                return null;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return null;
    }
    }
    
    public ItemCarrito agregarCarrito(int id, int cant) throws SQLException{
        try{
            conn = ConectarBD.abrir();
            
            String sql = "select obtenerPrecio("+id+") as precio;";
            rs = pstm.executeQuery(sql);
            double precio;
            
            String sql2 = "select obtenerNombre("+id+") as nombre;";
            rs = pstm.executeQuery(sql2);
            String nombre;
            
            if(rs.next()){
                precio = rs.getDouble("precio");
                nombre = rs.getString("nombre");
                ItemCarrito carrito = new ItemCarrito(id, cant, precio, nombre);
                ConectarBD.cerrar();
                return carrito;
            }else{
                ConectarBD.cerrar();
                return null;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return null;
    }
    }

    public boolean crearVenta(List<ItemCarrito> carrito) throws SQLException{
        int[] resultado;
        try{
            conn = ConectarBD.abrir();
            conn.setAutoCommit(false);

            LocalDate fecha = LocalDate.now();

            String idsql = "call realizar_venta_sp(fechaVenta) VALUES (?)";
            pstm = conn.prepareStatement(idsql, Statement.RETURN_GENERATED_KEYS);
            pstm.setDate(1, java.sql.Date.valueOf(fecha));
            
            int filas = pstm.executeUpdate();
            if (filas == 1) {
                rs = pstm.getGeneratedKeys();
                if (rs.next()) {
                    int idVenta = rs.getInt(1);            

                    String sql = "call realizar_descripcion_venta_sp(?, ?, ?, ?);";
                    pstm = conn.prepareStatement(sql);
                    
                    for(ItemCarrito item : carrito){
                        pstm.setInt(1, idVenta);
                        pstm.setInt(2, item.getIdProd());
                        pstm.setInt(3, item.getCantidad());
                        pstm.setDouble(4, item.getPrecio() * item.getCantidad());
                        
                        pstm.addBatch();
                    }

                    resultado = pstm.executeBatch();
                    conn.commit();
                    conn.setAutoCommit(true);
            } else {
                    conn.rollback();
                }
            } else {
                conn.rollback();
            }
            if(resultado != null){
                ConectarBD.cerrar();
                return true;
            }else{
                ConectarBD.cerrar();
                return false;
            }
    }catch (SQLException e){
            System.out.println("Error en la Base de Datos");
            return false;
    }
    }
}
