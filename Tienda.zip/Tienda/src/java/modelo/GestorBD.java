package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class GestorBD {
    Connection conn = null;
    Statement stm = null;
    ResultSet rs;
    Producto prod;
    Venta venta;
    Historial hist;
    
    
}
