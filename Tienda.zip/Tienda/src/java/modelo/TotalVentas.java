package modelo;

public interface TotalVentas {
    double totalVendido();
}
