package modelo;

//Interfaz importable para calcular el total de ventas; Hecho por Candia
public interface TotalVentas {

    //El método que calcularía el total vendido
    double totalVendido();
}
