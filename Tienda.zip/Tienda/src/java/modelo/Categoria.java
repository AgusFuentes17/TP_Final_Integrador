package modelo;

public enum Categoria {
    agua;
    
}
