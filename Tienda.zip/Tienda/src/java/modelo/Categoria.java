package modelo;

public enum Categoria {
    agua,
    verduleria,
    jugo,
    carniceria,
    panaderia,
    gaseosa;
    
}
