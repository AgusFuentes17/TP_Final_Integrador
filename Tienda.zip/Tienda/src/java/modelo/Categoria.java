package modelo;

public enum Categoria {
    
}
