package modelo;

//Clase enum que representa la categoria de un producto; Hecho por Candia
public enum Categoria {
    agua,
    verduleria,
    jugo,
    carniceria,
    panaderia,
    gaseosa;
    
}
