package modelo;

import java.time.LocalDate;

//Clase que representa un historial de los productos; Hecho por Candia
public class Historial {

    //Atributos
    int idHistorial;
    LocalDate fechaHistorial;
    int cantVentas;
    Producto producto;

    //Constructor
    public Historial(int id, LocalDate fecha, int cant, Producto prod) {
        this.idHistorial = id;
        this.fechaHistorial = fecha;
        this.cantVentas = cant;
        this.producto = prod;
    }
    
    //Getters y Setters
    public void setIdHistorial(int id){
        this.idHistorial = id;
    }

    public int getIdHisorial(){
        return this.idHistorial;
    }

    public void setFechaHistorial(LocalDate f){
        this.fechaHistorial = f;
    }

    public LocalDate getFechaHistorial(){
        return this.fechaHistorial;
    }

    public void setCantVentas(int cant){
        this.cantVentas = cant;
    }

    public int getCantVentas(){
        return this.cantVentas;
    }

    public void setProducto(Producto prod){
        this.producto = prod;
    }

    public Producto getProducto(){
        return this.producto;
    }
}
