package modelo;

public class Historial {
    
}
