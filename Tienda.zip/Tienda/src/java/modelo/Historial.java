package modelo;

import java.time.LocalDate;

public class Historial {
    int idHistorial;
    LocalDate fechaHistorial;
    int cantVentas;
    Producto producto;

    public Historial(int id, LocalDate fecha, int cant, Producto prod) {
        this.idHistorial = id;
        this.fechaHistorial = fecha;
        this.cantVentas = cant;
        this.producto = prod;
    }
    
    public void setIdHistorial(int id){
        this.idHistorial = id;
    }

    public int getIdHisorial(){
        return this.idHistorial;
    }

    public void setFechaHistorial(LocalDate f){
        this.fechaHistorial = f;
    }

    public LocalDate getFechaHistorial(){
        return this.fechaHistorial;
    }

    public void setCantVentas(int cant){
        this.cantVentas = t;
    }

    public int getCantVentas(){
        return this.cantVentas;
    }

    public void setProducto(Producto prod){
        this.producto = prod;
    }

    public Producto getProducto(){
        return this.producto;
    }
}
