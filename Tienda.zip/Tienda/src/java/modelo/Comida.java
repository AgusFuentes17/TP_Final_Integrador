package modelo;

//Clase hiija de producto que representa una comida; Hecho por Candia
public class Comida extends Producto{

    //Constructor
    public Comida(String n, Categoria c, double p, int cant) {
        super(n, c, p, cant);
    }

    //Método toString
    @Override
    public String toString() {
        return "Comida{" + '}';
    }
    
}
