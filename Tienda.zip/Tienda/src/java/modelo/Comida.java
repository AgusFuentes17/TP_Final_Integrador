package modelo;

public class Comida extends Producto{

    String tipo = "Comida";

    public Comida(String n, Categoria c, double p, int cant) {
        super(n, c, p, cant);
    }

    public void setTipo(String t){
        this.tipo = t;
    }

    public String getTipo(){
        return this.tipo;
    }

    @Override
    public String toString() {
        return "Comida{" + '}';
    }
    
}
