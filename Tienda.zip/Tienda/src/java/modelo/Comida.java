package modelo;

public class Comida {
    
}
