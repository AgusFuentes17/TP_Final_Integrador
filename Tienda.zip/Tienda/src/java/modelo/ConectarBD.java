package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Clase para conectar java con mysql; Hecho por Agustin Fuentes
public class ConectarBD {

    //Atributos
    private static Connection connect;
    private static String bd = "Tienda";
    private static String user = "root";
    private static String contra = "";
    private static String url = "jdbc:mysql://localhost/" + bd;
    
    //Método para abrir la conexión con la base de datos
    public static Connection abrir() throws SQLException{
        try{ //Si no ocurre un error, la conexión se hará correctamente
            Class.forName("com.mysql.cj.jdbc.Driver");
            connect = DriverManager.getConnection(url, user, contra);
        } catch(ClassNotFoundException e){ //Si ocurre un error, la conexión no se hará correctamente
            System.out.println("Error: No se pudo cargar el controlador JDBC.");
            throw new SQLException("Error en la conexión", e);
        }
        return connect;
    }
    
    //Método para cerrar la conexión con la base de datos
    public static void cerrar(){
        try{ //Si no ocurre un error, la conexión se cerrará correctamente
            if (connect != null)
                connect.close();
        }catch(SQLException e){ //Si ocurre un error, la conexión no se cerrará correctamente
            System.out.println("Error: No se logró cerrar la conexión:\n" + e);
        }
    }
}
