package modelo;

public class ConectarBD {
    
}
