package modelo;

public class Bebida {
    
}
