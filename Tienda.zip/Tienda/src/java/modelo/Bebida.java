package modelo;

public class Bebida extends Producto {

    String tipo = "Bebida";

    public Bebida(String n, Categoria c, double p, int cant) {
        super(n, c, p, cant);
    }

    public void setTipo(String t){
        this.tipo = t;
    }

    public String getTipo(){
        return this.tipo;
    }

    @Override
    public String toString() {
        return "Bebida{" + '}';
    }
    
}
