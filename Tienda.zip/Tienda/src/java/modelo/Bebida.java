package modelo;

//Clase hija de Producto que representa una bebida; Hecho por Candia
public class Bebida extends Producto {

    //Constructor
    public Bebida(String n, Categoria c, double p, int cant) {
        super(n, c, p, cant);
    }

    //Método toString
    @Override
    public String toString() {
        return "Bebida{" + '}';
    }
    
}
