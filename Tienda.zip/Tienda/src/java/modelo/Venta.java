package modelo;

public class Venta {
    
}
