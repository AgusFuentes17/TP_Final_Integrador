package modelo;

import java.time.LocalDate;
import java.util.ArrayList;

//Esta clase representa una Venta de la base de datos; Hecho por Candia 
public class Venta implements TotalVentas{

    //Atributos
    int idVenta;
    LocalDate fechaVenta;
    int cantVendido;
    ArrayList<Producto> productos;

    //Constructor
    public Venta(int id, LocalDate fecha, int cant) {
        this.idVenta = id;
        this.fechaVenta = fecha;
        this.cantVendido = cant;
        ArrayList<Producto> productos = new ArrayList<>();
    }
    
    //Getters y Setters
    public void setIdVenta(int id){
        this.idVenta = id;
    }

    public int getIdVenta(){
        return this.idVenta;
    }

    public void setFechaVenta(LocalDate f){
        this.fechaVenta = f;
    }

    public double getFechaVenta(){
        return this.fechaVenta;
    }

    public void setCantVendido(int cant){
        this.cantVendido = cant;
    }

    public int getCantVendido(){
        return this.cantVendido;
    }

    public void setProductos(ArrayList<Producto> p){
        this.productos = p;
    }

    public ArrayList<Producto> getProducto(){
        return this.productos;
    }

    //Método para agregar un producto al ArrayList de productos
    public void agregarProducto(Producto p){
        productos.add(p);
    }

    //Método totalVendido de la interfaz importable TotalVentas
    @Override
    public double totalVendido (){
        double total;
        for(Producto p : productos){
            total += p.getPrecio();
        }
        return total;
    }

}


