package modelo;

//Clase que representa el carrito de la compra al momento de la venta; Hecho por Candia
public class ItemCarrito {

    //Atributos
    static int numeroCarrito = 0; //Variable static para representar el ID del carrito
    int idCarrito;
    String nombre;
    int cantidad;
    double precio;
    int idProd;

    //Constructor
    public ItemCarrito(int id, int cant, double p, String n){
        this.numeroCarrito++;
        this.idCarrito = numeroCarrito;
        this.idProd = id;
        this.cantidad = cant;
        this.precio = p;
        this.nombre = n;
    }

    //Getters y Setters
    public static void setNumeroCarrito(int num){
        this.numeroCarrito = num;
    }

    public static int getNumeroCarrito(){
        return this.numeroCarrito;
    }

    public void setIdCarrito(int id){
        this.idCarrito = id;
    }

    public int getIdCarrito(){
        return this.idCarrito;
    }

    public void setNombre(String n){
        this.nombre = n;
    }

    public String getNombre(){
        return this.nombre;
    }

    public void setCantidad(int cant){
        this.cantidad = cant;
    }

    public int getCantidad(){
        return this.cantidad;
    }

    public void setPrecio(double p){
        this.precio = p;
    }

    public double getPrecio(){
        return this.precio;
    }

    public void setIdProd(int id){
        this.idProd = id;
    }

    public int getIdProd(){
        return this.idProd;
    }
}
