package modelo;

public class ItemCarrito {
    
}
